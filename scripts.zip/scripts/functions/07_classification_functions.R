suppressPackageStartupMessages({
    library(dplyr)
    library(tibble)
    library(ggplot2)
    library(randomForest)
    library(pROC)
    library(forcats)
    library(stringr)
})

# ------------------------------------------------------------------------------
# Function: prepare_classification_data
# ------------------------------------------------------------------------------
# Description:
#   Combines abundance matrix with metadata and prepares disease_status as binary
#   classification target.
# ------------------------------------------------------------------------------
prepare_classification_data<- function(mat, metadata) {
    matched <- match_samples(mat, metadata) # returns matrix with common samples

    # Create df 
    df <- matched$mat %>% 
        as.data.frame() %>% 
        tibble::rownames_to_columns("sample_id") %>% 
        left_join(
            matched$metadata %>% select(sample_id, disease_status),
            by = "sample_id"
        )

    if (any(is.na(df$disease_status))) {
        stop("Missing disease_status after joining metadata")
    }

    df %>% 
        mutate(
            disease_status = factor(disease_status, levels = c("healthy", "IBD"))
        )
}


# ------------------------------------------------------------------------------
# Function: split_train_test
# ------------------------------------------------------------------------------
# Description:
#   Stratified train/test split preserving disease_status proportions
#
# ------------------------------------------------------------------------------
split_train_test <-  function(df, test_fraction=0.25, seed = 123) {
    set.seed(seed)
    test_idx <- df%>% 
        mutate(row_id = row_number()) %>% 
        group_by(disease_status) %>% 
        group_modify(~ {
            n_test <- ceiling(nrow(.x) * test_fraction) #.x means actual group - IBD or healthy
            tibble(row_id = sample(.x$row_id, size = n_test)) #RAndomly draw ntest rows
        })%>% 
        ungroup() %>% 
        pull(row_id) #extract rowid as vector
    
    train_idx <- setdiff(seq_len(nrow(df)), test_idx)
    
    train_df <- df[train_idx, drop = FALSE]
    test_df <- df[test_idx drop = FALSE]

    list(train = train_df, 
        test = test_df)
}


# ------------------------------------------------------------------------------
# Function: train_random_forest
# ------------------------------------------------------------------------------
# Description:
#   Trains a random forest classifier.
# ------------------------------------------------------------------------------
train_random_forest <- function(df, seed = 123) {
    set.seed(seed)

    x_train <- df %>% 
        select(-sample_id, -disease_status)
    y_train <- df$disease_status #Labels

    randomForest::randomForest(
        x = x_train,
        y = y_train,
        ntree = 500,
        imporance = TRUE
    )
}


# ------------------------------------------------------------------------------
# Function: evaluate_random_forest
# ------------------------------------------------------------------------------
# Description:
#   Evaluates a random forest on test set and returns metrics
# ------------------------------------------------------------------------------
evaluate_random_forest <- function(model, df, feature_set) {
    x_test <- df %>% 
        select(-sample_id, -disease_status)
    y_true <- df$disease_status

    predicted_class <- predict(model, x_test, type = "response")
    predicted_prob <- predict(model, y_true, type = "prob")[, "IBD"]

    cm <- table(
        truth = factor(y_true, levels = c("healthy", "IBD")),
        predicted = factor(predicted_class, levels = c("healthy", "IBD"))
    )
    
    accuracy <- sum(diag(cm)) / sum(cm)

    sensitivity <- cm["IBD", "IBD"] / sum(cm["IBD", ]) # What percent of true IBD samples the model recognised as IDB
    specificity <- cm["healthy", "healthy"] / sum(cm["healthy", ]) #What percent of true healthy samples the model recognized as healthy

    balanced_accuracy <- mean(c(sensitivity, specificity), na.rm = TRUE)

    roc_obj <- pROC::roc(
        response = y_true,
        predictor = predicted_prob,
        levels = c("healthy", "IBD"),
        quiet = TRUE
    )

    auc <- as.numeric(pROC::auc(roc_obj))

    tibble(
        feature_set = feature_set,
        model = "random_forest",
        accuracy = accuracy,
        balanced_accuracy = balanced_accuracy,
        sensitivity = sensitivity,
        specificity = specificity,
        auc = auc,
        n_train = nrow(model$votes),
        n_test = nrow(df)
    )

}


# ------------------------------------------------------------------------------
# Function: extract_feature_importance
# ------------------------------------------------------------------------------
# Description:
#   Extracts random forest feature importance.
# ------------------------------------------------------------------------------
extract_feature_importance <- function(model, feature_set) {
    importance_df <- randomForest::importance(model) %>%
        as.data.frame() %>%
        tibble::rownames_to_column("feature")

    importance_col <- if ("MeanDecreaseGini" %in% colnames(importance_df)) {
        "MeanDecreaseGini"
    } else {
        colnames(importance_df)[ncol(importance_df)]
    }

    importance_df %>%
        transmute(
        feature_set = feature_set,
        feature = feature,
        importance = .data[[importance_col]]
        ) %>%
        arrange(desc(importance))
}




# ------------------------------------------------------------------------------
# Function: shorten_feature_name_for_classification
# ------------------------------------------------------------------------------
shorten_feature_name_for_classification <- function(feature, feature_set) {
    if (feature_set == "pathways") {
        feature %>%
        stringr::str_replace("__.*$", "")%>%
        stringr::str_replace_all("[_\\-]+", " ") %>%
        stringr::str_squish()
    } else {
        feature %>%
        stringr::str_replace_all("_", " ") %>%
        stringr::str_squish() %>% 
        stringr::word(1, 2)
    }
}


# ------------------------------------------------------------------------------
# Function: plot_auc_comparison
# ------------------------------------------------------------------------------
plot_auc_comparison <- function(metrics_df) {
    ggplot(
        metrics_df,
        aes(x = feature_set, y = auc)
    ) +
        geom_col() +
        ylim(0, 1) +
        theme_minimal(base_size = 12) +
        labs(
        title = "Classification performance: taxa vs pathways",
        x = NULL,
        y = "AUC"
        )
}


# ------------------------------------------------------------------------------
# Function: plot_feature_importance
# ------------------------------------------------------------------------------
plot_feature_importance <- function(importance_df, selected_feature_set, ntop = 20) {
    plot_df <- importance_df %>%
        filter(feature_set == selected_feature_set) %>%
        arrange(desc(importance)) %>%
        slice_head(n = ntop) %>%
        mutate(
        feature_short = vapply(
            feature,
            shorten_feature_name_for_classification,
            character(1),
            feature_set = selected_feature_set

        ),
        feature_short = forcats::fct_reorder(feature_short, importance)
        )

    ggplot(
        plot_df,
        aes(x = feature_short, y = importance) 
    ) +
        geom_col() +
        coord_flip() +
        theme_minimal(base_size = 11) + 
        labs(
        title=paste("Top ", ntop, selected_feature_set, "features in random forest"),
        x = NULL,
        y = "Feature importance"
        )
    }